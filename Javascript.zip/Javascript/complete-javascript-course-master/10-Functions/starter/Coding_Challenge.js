
const poll = {
    question: 'What is your favourite programming language?',
    options: ['0: JavaScript', '1: Python', '2: Rust', '3: C++'],
    // This generates [0, 0, 0, 0]. More in the next section ðŸ˜ƒ
    // answerArray = new Array(0,1,2,3),
    answers: new Array(4).fill(0),

    registerNewAnswer() {
        let answer = Number(prompt(`${this.question} \n ${this.options[0]} \n ${this.options[1]} \n ${this.options[2]} \n ${this.options[3]} \n (Write Option Number)`));
        // this.answerArray.includes(answer) ? this.answers[answer]++ : alert("Please Enter the Valid Answer !!") ;
    }



};

document.querySelector('.poll').addEventListener('click', poll.registerNewAnswer);