'use strict';

let secretNumber = Math.floor(Math.random()*(20 - 1 + 1) + 1);
let score = 20;
let highscore = 0;

const displayMessage = function(message) {
    return document.querySelector(".message").textContent = message;
}

console.log(secretNumber)
document.querySelector(".check").addEventListener('click', function() {
    const guessValue = Number(document.querySelector(".guess").value);

    if(!guessValue) {
        displayMessage("Please enter number 😊.");
        document.querySelector(".message").textContent = "Please select number from 1 to 20 😊."
    }else if(guessValue < 1 || guessValue > 20) {
        displayMessage("Please enter number from 1 to 20 😊.")
        // document.querySelector(".guess").textContent = "";
    }else if(guessValue === secretNumber) {
        document.querySelector("body").style.backgroundColor = '#60b347';
        document.querySelector(".number").style.width = '30rem';
        document.querySelector(".number").textContent = secretNumber;
        displayMessage("🏆 Correct Number!!");

        if(score > highscore) {
            highscore = score;
        }
        document.querySelector(".highscore").textContent = highscore;
    }else {
        
        if(guessValue > secretNumber) {
            displayMessage("Number is too high 😊.");
        } else if(guessValue < secretNumber) {
            displayMessage("Number is too low 😊.");          
        }
        if(score > 1) {
            score--;
            document.querySelector(".score").textContent = score;
        }else {
            document.querySelector(".score").textContent = 0;
            displayMessage("Game Over 😭.")
        }
    }                 
});

document.querySelector(".again").addEventListener('click', function() {
    document.querySelector("body").style.backgroundColor = '#222';
    document.querySelector(".number").style.width = '15rem';
    document.querySelector(".number").textContent = '?';
    displayMessage("Start guessing...");
    document.querySelector(".highscore").textContent = 0;
    document.querySelector(".guess").value = '';
    score = 20;  
    document.querySelector(".score").textContent = score;
    secretNumber = Math.floor(Math.random()*(20 - 1 + 1) + 1);
    console.log(secretNumber)
});