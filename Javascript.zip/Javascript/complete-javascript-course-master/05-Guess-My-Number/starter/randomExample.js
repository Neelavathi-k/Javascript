for(let i =0; i <20; i++) {
    randomNumber = Math.random()*(20 - 1 + 1) + 1;
    console.log(randomNumber);
}

// randomFloor = Math.floor(randomNumber);
// console.log("randomFloor *** " + randomFloor);

// randomCeil = Math.ceil(randomNumber);
// console.log("randomCeil *** " + randomCeil);