"use strict";

//Challenge_01

/*const calcAverage = score => score/3;

function checkWinner(dolphinAvg, kolasAvg) {
    if(kolasAvg >= (2 * dolphinAvg)) {
        console.log("Kolas are win the trophy 🏆");
    }else if(dolphinAvg >= (2 * kolasAvg)) {
        console.log("Dolphins are win the trophy 🏆");
    }else {
        console.log("No one win the trophy!! 😟");
    }
}

let dolphinScore = 44 + 23 + 71;
let kolasScore = 65 + 54 + 49;

let dolphinAvg = calcAverage(dolphinScore);
let kolasAvg = calcAverage(kolasScore);

console.log(dolphinAvg, kolasAvg);

checkWinner(dolphinAvg, kolasAvg)*/

//Challenge_02

/*const calcTip = function(billAmount) {
   return (billAmount >= 50 && billAmount <= 300) ? (billAmount * (15/100)) : (billAmount * (20/100));
}

let billArray = [125, 555, 44]
let tipArray = [calcTip(billArray[0]), calcTip(billArray[1]), calcTip(billArray[2])];
let totalArray = [billArray[0]+tipArray[0], billArray[1]+tipArray[1], billArray[2]+tipArray[2]]

console.log(totalArray);*/

//Challenge_03

 /*const mark = {
     name: 'Mark Miller',
     weight: 78,
     height: 1.69,
     calcBmi: function() {
         this.bmi =  this.weight / (this.height ** 2);
         return this.bmi;
     },
     printBmi: function() {
         return `${this.name}'s BMI (${this.bmi}) is higher than ${john.name}'s (${john.bmi})`;
     }
 }

 const john = {
    name: 'John Smith',
    weight: 92,
    height: 1.95,
    calcBmi: function() {
        this.bmi =  this.weight / (this.height ** 2);
        return this.bmi;
    },
    printBmi: function() {
        return `${this.name}'s BMI (${this.bmi}) is higher than ${mark.name}'s (${mark.bmi})`;
    }
 }

 const markBmi = mark.calcBmi();
 const johnBmi = john.calcBmi();

 console.log(markBmi, johnBmi); 

 const result = markBmi > johnBmi ? mark.printBmi() : john.printBmi();
 console.log(result)*/

//Challenge_04

const calcTip = function(billAmount) {
    return (billAmount >= 50 && billAmount <= 300) ? (billAmount * (15/100)) : (billAmount * (20/100));
 }

const calcAverage = function(totalArray) {
    console.log

    let sum = 0;
    for(let i = 0; i < totalArray.length; i++) {
        sum += totalArray[i];
    }
    return sum/totalArray.length;
}

const bill = [22, 295, 176, 440, 37, 105, 10, 1100, 86, 52];

const tip = new Array();
const total = new Array();

 for(let i = 0; i < bill.length; i++) {
     tip.push(calcTip(bill[i]));
     total.push(tip[i] + bill[i]);
 }

const average =  calcAverage(total);
console.log(`The average value is ${average}`);