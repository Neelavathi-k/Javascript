'use script';            //To Activate the sctrict mode for secure javascript

/*
//FUNCTION DECLARATION 

function calcAge1(birthYear) {
    return 2021 - birthYear;
}

//FUNCTION EXPRESSION

let calcAge2 = function (birthYear) {
    return 2021 - birthYear;
}

let age1 = calcAge1(1998); //we can cl the func before/after declaration.
let age2 = calcAge2(1998); //we can cl the func after declaration only
console.log(age1, age2);


//ARROW FUNCTION
const calcAge3 = birthYear => 2021 - birthYear;
let age3 = calcAge3(1998);
console.log(age3);

let calcAge4 = (birthYear, firstName) => {
    let age4 = 2021 - birthYear;
    let retirementAge = 65 - age4;
    return `${firstName} retires in ${retirementAge} years`;
}

console.log(calcAge4(1998, 'Neelavathi K'));
*/

//ARRAY

/*const array1 = ['BE','B.COM','BTECH']
console.log(array1);
console.log(array1.length);

const array2 = new Array(1998,1999,2000,2001)
console.log(array2)
console.log(array2.length)

array1[1] = 'BSC'
array1.push('B.COM') //It will add the element at the end of the array and return the length of new array.
array1.unshift('B.Ed'); //It will add the element at the bigining of the array and return the length of new array.
console.log(array1)

array1.pop(); //removes the element from the end of the array and returns the popped element
array1.shift(); //removes the element from the bigining  of the array and returns the popped element
console.log(array1);

console.log(array1.indexOf('BE')) //To find the position of the element in the array.
console.log(array1.indexOf('B.COM'))

console.log(array1.includes('BE')) //To find the whether element is present in the array or not.
console.log(array1.includes('B.COM'))

array1.push(20);
console.log(array1.includes('20'))
console.log(array1.includes(20))*/

const neela = {
    firstName: 'Neelavathi',
    lastName: 'K',
    age: 2021 - 1998,
    job: 'Software Developer',
    education: ['10th', '12th', 'B.E']
};

neela.location = 'India';
neela['emailId'] = 'neelavathicse@gmail.com';

console.log(neela);

console.log(neela.firstName); //In dot we can't pass any expression we can only pass the property
console.log(neela['lastName']); //In brackets we can pass expression as well as property.

const nameKey = 'Name';
console.log(neela['first' + nameKey]);
console.log(neela['last' + nameKey]);
// console.log(neela.'first'+nameKey); it will throw the error.

const interested =  prompt("What you want to know about neela? Choose between firstName, lastName, age, job, location, emailId and education.")
console.log(interested);
console.log(neela.interested); // it will return undefined

if(neela[interested]) {
    console.log(neela[interested]);
}else {
    console.log(`We don't ${interested} of neela.`)
}

console.log(`${neela.firstName} ${neela.lastName} completed the ${neela.education.length} courses and her favorite course is ${neela.education[2]}.`);
//WE CAN MAINTAIN ALL KIND OF DATATYPE INSIDE THE OBJ

