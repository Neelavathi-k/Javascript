/*let js = "amazing";
if(js == "amazing") alert("JAVASCRIPT IS FINE!!!!");
console.log(40+10+20-5);
console.log(js);*/

// const country = "India";
// const continent = "Asia"
// let population = 2000000;

// console.log(country);
// console.log(continent);
// console.log(population);

// let javascriptIsFun = true;
// console.log(javascriptIsFun);

// console.log(typeof true);
// console.log(typeof javascriptIsFun);
// console.log(typeof 23);
// console.log(typeof "Neela");

// javascriptIsFun = 'Neelavathi K'
// console.log(javascriptIsFun);
// console.log(typeof javascriptIsFun);

// let value;
// console.log(value)
// console.log(typeof value)

// let isIsland = false;
// let language = Tamil;

// country = "america"; //IT WILL THROW THE ERROR AS  country IS DECLARED AS CONST

// console.log(country)


//Type Conversion
let birthyear = '1998';
console.log(Number(birthyear) + 2, birthyear);
console.log(Number('Neelavathi'))
console.log(typeof NaN)
console.log(String(23));

//Type Coersion
//Type coersion is the process of change the datatype of the result if the inputs are different datatype implicitly.
//if + operator there then converts into string
//For rest operator convert in to integer

let firstName = '1199' + 000;
console.log(firstName);
let lastName = '1199' - 000;
console.log(lastName);
let middleName = 'neela' - 12;
console.log(middleName)

const fav = prompt("what's your favorite number?");
console.log(fav);





























