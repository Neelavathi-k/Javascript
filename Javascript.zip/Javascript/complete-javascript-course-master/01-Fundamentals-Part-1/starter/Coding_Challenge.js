//Challenge #01

/*const markMass = 95;
const markHeight = 1.88;
const johnMass = 85;
const johnHeight = 1.76;

let markBmi = markMass / (markHeight ** 2);
let johnBmi = johnMass / (johnHeight ** 2);
console.log(markBmi, johnBmi);

let markHigherBmi = markBmi > johnBmi;
console.log(markHigherBmi);
console.log('String \n\  with  \n\  multiple lines🌹')*/

//Challenge #02

/*if(markHigherBmi) {
    console.log(`Mark's BMI ${markBmi} is higher than John's ${johnBmi}.`);
}else {
    console.log(`John's BMI ${johnBmi} is higher than Mark's ${markBmi}`);
}*/

//Challenge #03

/*dolphinsAvg = (97 + 112 + 80) / 3
// console.log(dolphinsAvg);

octopusAvg = (109 + 95 + 50) / 3;
// console.log(octopusAvg);

if(dolphinsAvg > octopusAvg && dolphinsAvg >= 100)  {
        console.log(`Dolphin team Won the trophy`);
}else if(octopusAvg > dolphinsAvg &&voctopusAvg >= 100) {
        console.log(`Octopus team Won the trophy`);
}else if(dolphinsAvg == octopusAvg && dolphinsAvg >= 100 && octopusAvg >= 100) {
    console.log("Mtch is draw!!");
}else {
    console.log("No one win the match!!!")
}*/

//Challenge #04

let billAmount = 430    ;
let tipPercentage = (billAmount >= 50 && billAmount <= 300) ? 15 : 20;

let tipAmount = billAmount * (tipPercentage / 100);
let totalAmount = tipAmount + billAmount;

console.log(`The bill was ${totalAmount}`);
