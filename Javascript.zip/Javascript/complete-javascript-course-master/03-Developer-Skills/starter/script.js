// Remember, we're gonna use strict mode in all scripts now!
'use strict';

/*const calcTempAmplitude = function(temperature) {
    let min = temperature[0];
    let max = temperature[0];
    for(let i = 0; i < temperature.length; i++) {
        if(typeof(temperature[i]) == 'number') {
            if(temperature[i] < min) {
                min = temperature[i];
            }
            if(temperature[i] > max) {
                max = temperature[i];
            }
        }
    }
    return max - min;
}

const temperature1 = [3, -2, -6, -1, 'error', 9, 13, 17, 15, 14, 9, 5]
const temperature2 = [4,5,6];
const temperature = temperature1.concat(temperature2);

let tempAmplitude = calcTempAmplitude(temperature);
console.log(tempAmplitude)*/

//TO CONVERT TEMP FROM CELCIUS TO KELVIN

const measureKelvein = function() {

    // const measurement
    const value =  prompt("Degree's in celcius: ");

    return Number(value) + 273;
}

console.log(measureKelvein());