"use script";

//Challenge_01

const printForeCast = function(temperature) {
    let solution = "";
    for(let i = 0; i < temperature.length; i++) {
        solution += `... ${temperature[i]}*C in ${i+1} days `;
    }    
    return solution;
}

const temp = [17, 21, 23]
const temp1 = [12,5, -5,0,4]

console.log(printForeCast(temp1))