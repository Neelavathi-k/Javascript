'use strict';

// Data needed for a later exercise
// const flights =
//   '_Delayed_Departure;fao93766109;txl2133758440;11:25+_Arrival;bru0943384722;fao93766109;11:45+_Delayed_Arrival;hel7439299980;fao93766109;12:05+_Departure;fao93766109;lis2323639855;12:30';

// Data needed for first part of the section
const restaurant = {
  name: 'Classico Italiano',
  location: 'Via Angelo Tavanti 23, Firenze, Italy',
  categories: ['Italian', 'Pizzeria', 'Vegetarian', 'Organic'],
  starterMenu: ['Focaccia', 'Bruschetta', 'Garlic Bread', 'Caprese Salad'],
  mainMenu: ['Pizza', 'Pasta', 'Risotto'],

  openingHours: {
    thu: {
      open: 12,
      close: 22,
    },
    fri: {
      open: 11,
      close: 23,
    },
    sat: {
      open: 0, // Open 24 hours
      close: 24,
    },
  },

  order: function (starterIndex, mainCourseIndex) { 
    return [this.starterMenu[starterIndex], this.mainMenu[mainCourseIndex]]
  },

  orderDelivery: function(obj) {
    console.log(`Your order ${this.starterMenu[obj.starterIndex]} and ${this.mainMenu[obj.mainIndex]} at ${obj.address} on ${obj.time}`);
  },

  orderPasta: function (ing1, ing2, ing3) {
    console.log(`your pasta is ready with ${ing1}, ${ing2} and ${ing3}`);
  }

};

//DESTRUCTING ARRAY
// let arr = [11, 12, 13]
// let[x, y, z] = arr;
// console.log(x, y, z);

// let[a, b, c, d] = arr;
// console.log(a, b, c, d);

// [a=1, b=1, c=1, d=1] = arr;
// console.log(a, b, c, d);

// let arr1 = [1, 2, [3,4]]
// let[p, q, r] = arr1;
// console.log(p, q, r);

// let[s, t] = r
// console.log(s, t)

// let [i, j, [k, l]] = arr1
// console.log(i, j, k, l)

// console.log("=======================")
// let[main, secondary] = restaurant.categories;
// console.log(main, secondary);

// [main, secondary] = [secondary, main];
// console.log(main, secondary);

// let[starter, mainCourse] = restaurant.order(2,3);
// console.log(starter, mainCourse);

//DESTRUCTING OBJECT

/*let {name, openingHours, categories} = restaurant;
console.log(name, openingHours, categories)

let {
  name: restaurantName,
  openingHours: hours,
  categories: tags
} = restaurant

let {
  menu = [],
  starterMenu: starters = []
} = restaurant

console.log(restaurantName, hours, tags)

// let {sat: {open, close}} = openingHours;
let {sat} = openingHours;
console.log(sat.open);
// console.log(open, close);

restaurant.orderDelivery({
  time: '23.30',
  address: 'trichy',
  mainIndex:2,
  starterIndex:0
}); */

//SPREAD OPERATOR

/*let arr = [2, 3, 4]
let newArray = [1, ...arr]
console.log(newArray)
let newArray1 = [...newArray]
console.log(newArray1)

let newArray2 = [...newArray1, 5]
console.log(newArray2)

let menu = [...restaurant.starterMenu, ...restaurant.mainMenu];
console.log(menu)

let firstName = 'Neelavathi'
let nameArray = [...firstName];
console.log(nameArray)

let ingredient = ['mushroom','cheese','butter'];
restaurant.orderPasta(...ingredient)*/

//SET

/*let orderSet = new Set(['Pizza','Pizza','Burger','Rotti','Rotti','Rotti']) //CREATION OF SET
console.log(orderSet.size); //TO GET LENGTH OF SET
console.log(orderSet.has('Pizza')); //TO CHECK WHETHER VALUE PRESENT OR NOT
console.log(orderSet.has('Bread'));
orderSet.add('Bread') //TO ADD THE ELEMENT INTO SET
orderSet.delete('Rotti') //TO DELETE THE ELEMENT FROM SET
//orderSet.clear(); //TO DELETE ALL ELEMENT FROM THE SET
console.log(orderSet);

for(let order of orderSet) {
  console.log(order)
}

let position = ['Waiter','Chef','Waiter','Cook','Server'];
let positionSet = new Set(position);
console.log(positionSet);

let positionArray = ['Manager', ...positionSet]
console.log(positionArray);

let nameSet = new Set("Neelavathi");
console.log(nameSet)
nameSet = new Set("NeElavathi");
console.log(nameSet)*/

//MAP

// let map = new Map();

// map.set('name', 'Classico Italian');
// map.set(1, 'Trichy');
// map.set(2, 'Tanjore');

// map.set('Category', ['Indian','Italian','Chinese','Japanese'])
//    .set('open', 10)
//    .set('close', 5)
//    .set(true, 'We will provide good service')
//    .set(false, 'We will not provide good service');

// console.log(map);   

// console.log(map.get('name'))
// console.log(map.get(true))

// console.log(map.has('Category'))
// map.delete(2);
// console.log(map)
// console.log(map.size)

// Maps: Iteration
/*const question = new Map([
  ['question', 'What is the best programming language in the world?'],
  [1, 'C'],
  [2, 'Java'],
  [3, 'JavaScript'],
  ['correct', 3],
  [true, 'Correct 🏆'],
  [false, 'Try again! 😟'],
]);

console.log(question.get('question'))
for(let [key, value] of question) {
  // console.log(typeof(key))
  if(typeof(key) === 'number') {
    console.log(`${key} ${value}`);
  }
}

let answer = Number(prompt(`Please enter your answer.`));

// (answer == Number(question.get('correct'))) ? console.log(question.get(true)) : console.log(question.get(false));

console.log(question.get(answer == Number(question.get('correct'))))*/

//String 
/*let airLine = "Air Indiar";
let plane = "A390";

console.log(plane[0])
console.log(plane[1])
console.log(plane[2])
console.log('B377'[0])
console.log(airLine.length);
console.log('B377'.length)

console.log(airLine.indexOf('r'))
console.log(airLine.lastIndexOf('r'))
console.log(airLine.indexOf('Indian'))
console.log(airLine.slice(4))
console.log(airLine.slice(4,7))

console.log(airLine.slice(0,airLine.indexOf(' ')))
console.log(airLine.slice(airLine.lastIndexOf(' ')+1, airLine.length))
console.log(airLine.slice(-2))
console.log(airLine.slice(1,-1))

const checkMiddleSeat = function(seat) {
  let alpha = seat.slice(-1);
  if(alpha === 'B' || alpha === 'E') {
    console.log(`${seat} is middle seat`)
  }else {
    console.log(`${seat} is not middle seat`)
  }
}

checkMiddleSeat('11B')
checkMiddleSeat('11C')
checkMiddleSeat('1E')

console.log(airLine.toLowerCase());
console.log(airLine.toUpperCase());

let passenger= 'neELa';
passenger = passenger.toLowerCase();
let passengerAlpha = passenger[0].toUpperCase();
console.log(passengerAlpha + passenger.slice(1))

let passengerEmail = 'neelavathicse@gmail.com'
let loginPassengerEmail = '  kkneelavathicse@gmail.com  \n'

let normalizedEmail = loginPassengerEmail.toLowerCase().trim();
console.log(normalizedEmail)

if(passengerEmail === normalizedEmail) {
  console.log("You can Loggin");
}else {
  console.log("You cannot Loggin");
}

let price = '288,97#';
let priceUs = price.replace('#','$').replace(',','.')
console.log(priceUs)

let announcement = "All Passengers Please come to Boarding door No.23. Boarding door No.23"
// announcement = announcement.replaceAll('door','gate');
announcement = announcement.replace(/door/g,'gate');
console.log(announcement)

console.log(announcement.includes('Passengers'));
console.log(announcement.includes('neela'));
console.log(announcement.startsWith('All'));
console.log(announcement.startsWith('Nee'));
console.log(announcement.endsWith('23'));
console.log(announcement.endsWith('2322'));

//SPLIT AND JOIN

let name = 'K.Neelavathi';
let [firstName, lastName] = name.split('.');
console.log(firstName + " *** " + lastName);

let joinString = ['Mrs.', name].join(' ');
console.log(joinString)

//CAPITALIZE
let captalizeString = function(name) {
  let nameArray = name.split(' ');
  let resultNameArray = new Array();

  for(let str of nameArray) {
    resultNameArray.push(str[0].toUpperCase() + str.slice(1).toLowerCase());
  }
  return resultNameArray.join(' ');
}

console.log(captalizeString("neelavathi is a software developer"));


//PADDING

let message = 'Go to gate 23';
console.log(message.padStart(20, '*').padEnd(30, '*'));

let maskCreditCard = function(number) {
  let lastFourDig = number.slice(-4);
  return lastFourDig.padStart(number.length, '*');  
}

console.log(maskCreditCard('12345678910034561234'));

//REPEAT

let msg = "I am good";
console.log(msg.repeat(5))*/

const flights =
  '_Delayed_Departure;fao93766109;txl2133758440;11:25+_Arrival;bru0943384722;fao93766109;11:45+_Delayed_Arrival;hel7439299980;fao93766109;12:05+_Departure;fao93766109;lis2323639855;12:30';

let flightsArray = flights.split('+');
console.log(flightsArray);
let stringArray;

for(let str of flightsArray) {
  let emoji = str.startsWith('_Delayed') ? '😔' : '';
  stringArray = str.split(";");
  let flightMsg = new Array();
  flightMsg.push(emoji);
  flightMsg.push(stringArray[0].replaceAll('_',' '));
  flightMsg.push('from');
  flightMsg.push(stringArray[1].slice(0,3).toUpperCase());
  flightMsg.push('to');
  flightMsg.push(stringArray[2].slice(0,3).toUpperCase());
  let [time1,time2] = stringArray[stringArray.length-1].split(":");
  flightMsg.push('('+time1+'h'+time2+')');
  console.log([flightMsg].join(" ").replaceAll(',',' ').padStart(100, " "));
}
