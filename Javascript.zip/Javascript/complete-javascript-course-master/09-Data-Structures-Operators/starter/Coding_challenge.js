const game = {
    team1: 'Bayern Munich',
    team2: 'Borrussia Dortmund',
    players: [
      [
        'Neuer',
        'Pavard',
        'Martinez',
        'Alaba',
        'Davies',
        'Kimmich',
        'Goretzka',
        'Coman',
        'Muller',
        'Gnarby',
        'Lewandowski',
      ],
      [
        'Burki',
        'Schulz',
        'Hummels',
        'Akanji',
        'Hakimi',
        'Weigl',
        'Witsel',
        'Hazard',
        'Brandt',
        'Sancho',
        'Gotze',
      ],
    ],
    score: '4:0',
    scored: ['Lewandowski', 'Gnarby', 'Lewandowski', 'Hummels'],
    date: 'Nov 9th, 2037',
    odds: {
      team1: 1.33,
      x: 3.25,
      team2: 6.5,
    },
  };
  
//Challenge 01

/*let [players1, players2] = game.players;

let [team1goalKeeper, ...team1fieldPlayer] = players1;
let [team2goalKeeper, ...team2fieldPlayer] = players2;

console.log(team1goalKeeper, team1fieldPlayer)
let[allPlayer] = [...players1, ...players2]

let team1playersFinal = [...players1, 'Neela', 'Nisha', 'Nivetha']
console.log(team1playersFinal)

let {odds: {team1, x:draw, team2}} = game;
console.log(team1, draw, team2)*/

//Challenge 02

/*for(let [goal,player] of game.scored.entries()) {
 console.log(`${goal + 1} ${player}`) 
}

let sum = 0;
for(let odd of Object.values(game.odds)) {
  sum += odd;
}

average = sum/Object.values(game.odds).length;
console.log("Average of odds: " + average);

for(let [team, odds] of Object.entries(game.odds)) {
  const teamStr = game[team] ? `victory ${game[team]}` : 'draw';
  console.log(`Odd of ${teamStr}: ${odds}`)
}*/

//Challenge 03

/* const gameEvents = new Map([
  [17, 'âš½ï¸ GOAL'],
  [36, 'ðŸ” Substitution'],
  [47, 'âš½ï¸ GOAL'],
  [61, 'ðŸ” Substitution'],
  [64, 'ðŸ”¶ Yellow card'],
  [69, 'ðŸ”´ Red card'],
  [70, 'ðŸ” Substitution'],
  [72, 'ðŸ” Substitution'],
  [76, 'âš½ï¸ GOAL'],
  [80, 'âš½ï¸ GOAL'],
  [92, 'ðŸ”¶ Yellow card'],
]);

let set = new Set(gameEvents.values());
let arr = [...set]
console.log(arr)

gameEvents.delete(64);
console.log(gameEvents); */

//Challenge 04

document.body.append(document.createElement('textarea'));
document.body.append(document.createElement('button'));
let inputText;
let inputArray;
let resultArray;

let captalizeString = function (name) {
  let nameArray = name.toLowerCase().trim().split('_');
  for(let i = 1; i < nameArray.length; i++) {   
    nameArray[i] = nameArray[i].replace(nameArray[i][0], nameArray[i][0].toUpperCase());
  }
  return [nameArray].join('').replace(',','');
}

document.querySelector('button').addEventListener('click', function () {
  console.log('inside listener')
  inputText = document.querySelector('textarea').value;
  console.log("*** " + inputText);

  inputArray = inputText.split('\n');
  console.log(inputArray);

  for(let s of inputArray.entries()) {
    if(s[1].includes('_')) {
      console.log(captalizeString(s[1]).padEnd(35, ' ') + '🤣'.repeat(s[0]+1));
    }else {
      console.log(s[1].padEnd(35, ' ') + '🤣'.repeat(s[0]+1));
    }
  }  
});
