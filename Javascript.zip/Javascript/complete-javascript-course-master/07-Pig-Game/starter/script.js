 'use strict';

const score0Ele = document.querySelector('#score--0');
const score1Ele = document.getElementById('score--1')
const diceEle = document.querySelector('.dice');
const btnNew = document.querySelector('.btn--new');
const btnRoll = document.querySelector('.btn--roll');
const btnHold = document.querySelector('.btn--hold');
const player0Ele = document.querySelector('.player--0');
const player1Ele = document.querySelector('.player--1');
const current0Ele = document.getElementById('current--0');
const current1Ele = document.getElementById('current--1');

//Initial setup for game
let Score = 0;
let playerId;
let currentScoreId;
let scoreId;
let player, currentScore,playing;

const init = function() {
    score0Ele.textContent = 0;
    score1Ele.textContent = 0;    
    current0Ele.textContent = 0;
    current1Ele.textContent = 0;
    player = 0;
    currentScore = 0;    
    playing = true;
    diceEle.classList.add('hidden')
    player0Ele.classList.remove('player--winner');
    player1Ele.classList.remove('player--winner');
    player0Ele.classList.add('player--active');
    player1Ele.classList.remove('player--active');
}

const player0Open = function() {
    player1Ele.classList.remove('player--active');
    player0Ele.classList.add('player--active');
}

const player1Open = function() {
    player0Ele.classList.remove('player--active');
    player1Ele.classList.add('player--active');
}

init();

btnRoll.addEventListener('click', function() {

    if(playing) {
            const dice = Math.trunc(Math.random() * 6) + 1;
        diceEle.classList.remove('hidden');
        diceEle.src = `dice-${dice}.png`;
        playerId = eval('player'+player+'Ele');
        currentScoreId = eval('current'+player+'Ele');

        if(player === 0) {
            if(dice !== 1) {        
                currentScore += dice;
            }else {
                currentScore = 0;
                player1Open();
                player = 1;
            }
        currentScoreId.textContent = currentScore; 
        }else if(player === 1) {
            if(dice !== 1) {        
                currentScore += dice;
            }else {
                currentScore = 0;
                player0Open();
                player = 0;
            }
        currentScoreId.textContent = currentScore; 
        }    
    }
})

btnHold.addEventListener('click', function() {

    if(playing) {
    
        scoreId = eval('score'+player+'Ele');
        Score = Number(scoreId.textContent) + currentScore;
        scoreId.textContent = Score;
        currentScoreId = eval('current'+player+'Ele');
        playerId = eval('player'+player+'Ele');
        
        if(Score >= 100) {
            // alert(`Player ${player+1} won the match!!`)
            playing= false;
            playerId.classList.add('player--winner');
            playerId.classList.remove('player--active')
            diceEle.classList.add('hidden')
            btnRoll.style.disable;
            btnHold.style.disable;
        }
        currentScore = 0;
        currentScoreId.textContent = currentScore; 
        if(player === 0) {
            player1Open();
            player = 1;
        }else if(player === 1) {
            player0Open();
            player = 0;
        }  
    }
})

btnNew.addEventListener('click', function() {
  init();
})
